# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 03:22:19 2024

@author: 91979
"""

import pandas as pan
import matplotlib
import seaborn as sns
import matplotlib.pyplot as plt
file = "C:/Users/91979/OneDrive/Desktop/group/K54Ddata_34927808.xlsx"

series = pan.read_excel(file, sheet_name='Sheet1', header=0, index_col=0, parse_dates=True).squeeze()

series.plot(title="Average weekly earnings time series", xlabel="Year", ylabel="Pounds")
plt.show()
file = "C:/Users/91979/OneDrive/Desktop/group/EAFVdata_34927808.xlsx"

series = pan.read_excel(file, sheet_name='Sheet1', header=0, index_col=0, parse_dates=True).squeeze()

series.plot(title=" Retail sales index", xlabel="Month", ylabel="Index")
plt.show()
file = "C:/Users/91979/OneDrive/Desktop/group/K226data_34927808.xlsx"

series = pan.read_excel(file, sheet_name='Sheet1', header=0, index_col=0, parse_dates=True).squeeze()

series.plot(title="  Extraction of crude petroleum and natural gas", xlabel="Year", ylabel="Index")
plt.show()
file = "C:/Users/91979/OneDrive/Desktop/group/JQ2Jdata_34927808.xlsx"

series = pan.read_excel(file, sheet_name='Sheet1', header=0, index_col=0, parse_dates=True).squeeze()

series.plot(title="   The manufacturing and business sector of Great Britain, total turnover and orders.", xlabel="Month", ylabel="Price")
plt.show()