

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np

ftse_data = pd.read_excel("C:/Users\91979\OneDrive\Desktop\group\FTSEdata_34927808.xlsx", sheet_name='Sheet1')
explanatory_data = pd.read_excel("C:/Users\91979\OneDrive\Desktop\group\FTSEdata_34927808.xlsx", sheet_name='Sheet2')

ftse_data['DATE'] = pd.to_datetime(ftse_data['DATE'], format='%Y %b')
ftse_data.set_index('DATE', inplace=True)

explanatory_data['DATE'] = pd.to_datetime(explanatory_data['DATE'], format='%Y %b')
explanatory_data.set_index('DATE', inplace=True)

combined_data = pd.merge(ftse_data, explanatory_data, left_index=True, right_index=True, how='inner')

print(combined_data.isnull().sum())

combined_data.dropna(inplace=True)

X = combined_data[['K54D', 'EAFV', 'K226', 'JQ2J']]
y = combined_data['Open']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

linear_model = LinearRegression()
linear_model.fit(X_train, y_train)
y_pred_linear = linear_model.predict(X_test)
mse_linear = mean_squared_error(y_test, y_pred_linear)
rmse_linear = np.sqrt(mse_linear)
print("Linear Regression:")
print("Mean Squared Error:", mse_linear)
print("Root Mean Squared Error:", rmse_linear)
print("R-squared:", r2_score(y_test, y_pred_linear))

plt.figure(figsize=(10, 6))
plt.scatter(y_test, y_pred_linear, color='orange', label='Linear Regression')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], linestyle='--', color='red', label='Line of Best Fit')
plt.xlabel('Actual Open')
plt.ylabel('Predicted Open')
plt.title('Linear Regression: Actual vs Predicted')
plt.legend()
plt.show()

ridge_model = Ridge(alpha=1.0) 
ridge_model.fit(X_train, y_train)
y_pred_ridge = ridge_model.predict(X_test)
mse_ridge = mean_squared_error(y_test, y_pred_ridge)
rmse_ridge = np.sqrt(mse_ridge)
print("\nRidge Regression:")
print("Mean Squared Error:", mse_ridge)
print("Root Mean Squared Error:", rmse_ridge)
print("R-squared:", r2_score(y_test, y_pred_ridge))

plt.figure(figsize=(10, 6))
plt.scatter(y_test, y_pred_ridge, color='green', label='Ridge Regression')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], linestyle='--', color='red', label='Line of Best Fit')
plt.xlabel('Actual Open')
plt.ylabel('Predicted Open')
plt.title('Ridge Regression: Actual vs Predicted')
plt.legend()
plt.show()

lasso_model = Lasso(alpha=1.0) 
lasso_model.fit(X_train, y_train)
y_pred_lasso = lasso_model.predict(X_test)
mse_lasso = mean_squared_error(y_test, y_pred_lasso)
rmse_lasso = np.sqrt(mse_lasso)
print("\nLasso Regression:")
print("Mean Squared Error:", mse_lasso)
print("Root Mean Squared Error:", rmse_lasso)
print("R-squared:", r2_score(y_test, y_pred_lasso))

plt.figure(figsize=(10, 6))
plt.scatter(y_test, y_pred_lasso, color='blue', label='Lasso Regression')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], linestyle='--', color='red', label='Line of Best Fit')
plt.xlabel('Actual Open')
plt.ylabel('Predicted Open')
plt.title('Lasso Regression: Actual vs Predicted')
plt.legend()
plt.show()

rf_model = RandomForestRegressor(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)
y_pred_rf = rf_model.predict(X_test)
mse_rf = mean_squared_error(y_test, y_pred_rf)
rmse_rf = np.sqrt(mse_rf)
print("\nRandom Forest Regression:")
print("Mean Squared Error:", mse_rf)
print("Root Mean Squared Error:", rmse_rf)
print("R-squared:", r2_score(y_test, y_pred_rf))

plt.figure(figsize=(10, 6))
plt.scatter(y_test, y_pred_rf, color='purple', label='Random Forest Regression')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], linestyle='--', color='red', label='Line of Best Fit')
plt.xlabel('Actual Open')
plt.ylabel('Predicted Open')
plt.title('Random Forest Regression: Actual vs Predicted')
plt.legend()
plt.show()
