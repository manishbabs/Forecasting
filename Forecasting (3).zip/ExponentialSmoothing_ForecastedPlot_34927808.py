

import pandas as pd
from statsmodels.tsa.holtwinters import ExponentialSmoothing
import matplotlib.pyplot as plt

df = pd.read_excel('C:/Users/91979/OneDrive/Desktop/group/K54Ddata_34927808.xlsx', sheet_name='Sheet1')

df[['Year', 'Month']] = df.iloc[:, 0].str.split(expand=True)
df['Value'] = df.iloc[:, 1].astype(float)  
df.drop(columns=[df.columns[0], df.columns[1]], inplace=True)

df['Date'] = pd.to_datetime(df['Year'] + ' ' + df['Month'], format='%Y %b')
df.set_index('Date', inplace=True)
df.drop(['Year', 'Month'], axis=1, inplace=True)

df.index = pd.DatetimeIndex(df.index.values, freq=df.index.inferred_freq)

model = ExponentialSmoothing(df['Value'], seasonal_periods=12, trend='add', seasonal='add')
hw_fit = model.fit()

forecast_end = pd.Timestamp('2024-12-31')
forecast_periods = (forecast_end.year - df.index[-1].year) * 12 + (forecast_end.month - df.index[-1].month)
hw_forecast = hw_fit.forecast(forecast_periods)

combined = pd.concat([df['Value'], hw_forecast], axis=0)

fig, ax = plt.subplots(figsize=(12, 7))

df['Value'].plot(label='Historical Data', ax=ax, color='blue')

hw_forecast.plot(ax=ax, label='Forecast', color='red', linestyle='--')

ax.set_xlabel('Date', fontsize=12)
ax.set_ylabel('Value', fontsize=12)
ax.set_title('K54D Series Forecast with Holt-Winters Method', fontsize=14)
ax.legend(loc='upper left')
ax.grid(True)

plt.tight_layout()
plt.show()


df = pd.read_excel('C:/Users/91979/OneDrive/Desktop/group/EAFVdata_34927808.xlsx', sheet_name='Sheet1')

df[['Year', 'Month']] = df.iloc[:, 0].str.split(expand=True)
df['Value'] = df.iloc[:, 1].astype(float)  
df.drop(columns=[df.columns[0], df.columns[1]], inplace=True)

df['Date'] = pd.to_datetime(df['Year'] + ' ' + df['Month'], format='%Y %b')
df.set_index('Date', inplace=True)
df.drop(['Year', 'Month'], axis=1, inplace=True)

df.index = pd.DatetimeIndex(df.index.values, freq=df.index.inferred_freq)

model = ExponentialSmoothing(df['Value'], seasonal_periods=12, trend='add', seasonal='add')
hw_fit = model.fit()

forecast_end = pd.Timestamp('2024-12-31')
forecast_periods = (forecast_end.year - df.index[-1].year) * 12 + (forecast_end.month - df.index[-1].month)
hw_forecast = hw_fit.forecast(forecast_periods)

combined = pd.concat([df['Value'], hw_forecast], axis=0)

fig, ax = plt.subplots(figsize=(12, 7))

df['Value'].plot(label='Historical Data', ax=ax, color='blue')

hw_forecast.plot(ax=ax, label='Forecast', color='red', linestyle='--')

ax.set_xlabel('Date', fontsize=12)
ax.set_ylabel('Value', fontsize=12)
ax.set_title('EAFV Series Forecast with Holt-Winters Method', fontsize=14)
ax.legend(loc='upper left')
ax.grid(True)

plt.tight_layout()
plt.show()


df = pd.read_excel('C:/Users/91979/OneDrive/Desktop/group/K226data_34927808.xlsx', sheet_name='Sheet1')

df[['Year', 'Month']] = df.iloc[:, 0].str.split(expand=True)
df['Value'] = df.iloc[:, 1].astype(float)  
df.drop(columns=[df.columns[0], df.columns[1]], inplace=True)

df['Date'] = pd.to_datetime(df['Year'] + ' ' + df['Month'], format='%Y %b')
df.set_index('Date', inplace=True)
df.drop(['Year', 'Month'], axis=1, inplace=True)

df.index = pd.DatetimeIndex(df.index.values, freq=df.index.inferred_freq)

model = ExponentialSmoothing(df['Value'], seasonal_periods=12, trend='add', seasonal='add')
hw_fit = model.fit()

forecast_end = pd.Timestamp('2024-12-31')
forecast_periods = (forecast_end.year - df.index[-1].year) * 12 + (forecast_end.month - df.index[-1].month)
hw_forecast = hw_fit.forecast(forecast_periods)

combined = pd.concat([df['Value'], hw_forecast], axis=0)

fig, ax = plt.subplots(figsize=(12, 7))

df['Value'].plot(label='Historical Data', ax=ax, color='blue')

hw_forecast.plot(ax=ax, label='Forecast', color='red', linestyle='--')

ax.set_xlabel('Date', fontsize=12)
ax.set_ylabel('Value', fontsize=12)
ax.set_title('K226 Series Forecast with Holt-Winters Method', fontsize=14)
ax.legend(loc='upper left')
ax.grid(True)

plt.tight_layout()
plt.show()

df = pd.read_excel('C:/Users/91979/OneDrive/Desktop/group/JQ2Jdata_34927808.xlsx', sheet_name='Sheet1')

df[['Year', 'Month']] = df.iloc[:, 0].str.split(expand=True)
df['Value'] = df.iloc[:, 1].astype(float)  
df.drop(columns=[df.columns[0], df.columns[1]], inplace=True)

df['Date'] = pd.to_datetime(df['Year'] + ' ' + df['Month'], format='%Y %b')
df.set_index('Date', inplace=True)
df.drop(['Year', 'Month'], axis=1, inplace=True)

df.index = pd.DatetimeIndex(df.index.values, freq=df.index.inferred_freq)

model = ExponentialSmoothing(df['Value'], seasonal_periods=12, trend='add', seasonal='add')
hw_fit = model.fit()

forecast_end = pd.Timestamp('2024-12-31')
forecast_periods = (forecast_end.year - df.index[-1].year) * 12 + (forecast_end.month - df.index[-1].month)
hw_forecast = hw_fit.forecast(forecast_periods)

combined = pd.concat([df['Value'], hw_forecast], axis=0)

fig, ax = plt.subplots(figsize=(12, 7))

df['Value'].plot(label='Historical Data', ax=ax, color='blue')

hw_forecast.plot(ax=ax, label='Forecast', color='red', linestyle='--')

ax.set_xlabel('Date', fontsize=12)
ax.set_ylabel('Value', fontsize=12)
ax.set_title('JQ2J Series Forecast with Holt-Winters Method', fontsize=14)
ax.legend(loc='upper left')
ax.grid(True)

plt.tight_layout()
plt.show()