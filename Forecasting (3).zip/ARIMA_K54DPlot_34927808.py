

import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.statespace.sarimax import SARIMAX


df = pd.read_excel('C:/Users/91979/OneDrive/Desktop/group/K54Ddata_34927808.xlsx', sheet_name='Sheet1')

df[['Year', 'Month']] = df.iloc[:, 0].str.split(expand=True)
df['Value'] = df.iloc[:, 1].astype(float) 

df.drop(columns=[df.columns[0], df.columns[1]], inplace=True)

df['Date'] = pd.to_datetime(df['Year'] + ' ' + df['Month'], format='%Y %b')
df.set_index('Date', inplace=True)
df.drop(['Year', 'Month'], axis=1, inplace=True)

df.index = pd.DatetimeIndex(df.index.values, freq=df.index.inferred_freq)

mod = SARIMAX(df['Value'], order=(1, 1, 1), seasonal_order=(1, 1, 1, 12))

results = mod.fit(disp=False)

pred = results.get_prediction(start=df.index[0], dynamic=False)

pred_ci = pred.conf_int()

fig, ax = plt.subplots(figsize=(12, 7))

df['Value'].plot(label='Original data', ax=ax, color='blue')

pred.predicted_mean.plot(ax=ax, label='One-step ahead Forecast', alpha=.7, color='orange')

ax.fill_between(pred_ci.index, pred_ci.iloc[:, 0], pred_ci.iloc[:, 1], color='k', alpha=.2)

pred_uc = results.get_forecast(steps=20)

pred_ci = pred_uc.conf_int()

pred_uc.predicted_mean.plot(ax=ax, label='Forecast values', title='Forecast plot with confidence interval', color='green')

ax.fill_between(pred_ci.index, pred_ci.iloc[:, 0], pred_ci.iloc[:, 1], color='k', alpha=.25)

ax.set_xlabel('Date', fontsize=12)
ax.set_ylabel('Value', fontsize=12)
ax.set_title('K54D Series Forecast with Confidence Interval', fontsize=14)
ax.legend(loc='upper left')
ax.grid(True)

ax.set_xlim(pd.Timestamp('2022-01-01'), pd.Timestamp('2024-12-31'))

ax.set_ylim(550, 800)

plt.tight_layout()
plt.show()
